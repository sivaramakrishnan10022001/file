
import './App.css';
import React , { useState, useEffect }from 'react';
import ButtonGroup from './components/assets/ButtonGroupDiv/ButtonGroupDiv';
import Dnd from './components/assets/dnd/dnd';
import { TreeView } from './components/assets/SampleTreeview/TreeView';
import TestingList from './components/assets/testinglist/testinglist';
// import Animation from './components/assets/Animation/Animation';
import { TreeviewTrial } from './components/assets/TestTreeFile/TreeDragDrop';
// import { ListView } from './components/assets/ListTest/ListView';
import IconPointer from './components/assets/iconPointer/iconPointer';
import IconBackground from './components/assets/iconbackground/iconbackground';
// import PdfViewer from './components/assets/pdfviewer/pdfviewer';
import IconTransition from './components/assets/iconTransition/IconTransition';
import IconUnderLine from './components/assets/iconUnderline/iconUnderline';
import CanvasArea from './components/assets/CanvasArea/CanvasArea';
import SlotBooking from './components/assets/SlotBooking/SlotBooking';
import MsfNavBar from './components/assets/msfnavbar/MSFNavbar';
import PdfViewer from './components/assets/pdfviewer/pdfviewer';
import PdfSlide from './components/assets/pdfviewer/pdfslide/pdfslide';
import NavDiv from './components/assets/responsivenavbar/navbar';
import { MContainedUploadButton, MOutLinedUploadButton, MTextUploadButton } from './components/assets/MaterialUploadBtn/uploadBtn';
// import VerticalStepper from './components/assets/Stepper/VerticalStepper';
import TestList from './components/assets/TestList/TestList';
import { TreeviewTest } from './components/assets/Treeview/TreeviewTest';
import Stepper from './components/assets/Stepper/Stepper';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import SampleVerticalStepper from './components/assets/Sample/sample';
///import AnimatedList from './components/assets/AnimatedList/AnimatedList';
import TestStepper from './components/assets/TestStepper/TestStepper';
import TestSample from './components/assets/TestSample/TestSample';
import { ReactComponent as Home } from '../src/assets/icons/home.svg';
import { ReactComponent as Heart } from '../src/assets/icons/heart.svg';
import { ReactComponent as Search } from '../src/assets/icons/search.svg';
import { ReactComponent as Avatar } from '../src/assets/icons/avatar.svg';
import { ReactComponent as Bell } from '../src/assets/icons/bell.svg';

function App() {
  const [categories, setCategories] = useState([]);
  const [elements, setElements] = useState([]);
  const [selectedItem, setSelectedItem] = useState();
  const [reload, setReload] = useState(false);
   
  var listData = ["Arun", "Arjun", "Lakshmi", "Sneha", "Vidya", "Dina", "Rohan", "Yash", "Kumar", "Aaran", "Aaren", "Aarez", "Aarman", "Aaron", "Aaron-James", "Aarron", "Aaryan", "Aaryn", "Aayan", "Aazaan", "Abaan", "Abbas", "Abdallah", "Abdalroof", "Abdihakim", "Abdirahman", "Abdisalam", "Abdul", "Abdul-Aziz", "Abdulbasir", "Abdulkadir", "Abdulkarem", "Abdulkhader", "Abdullah", "Abdul-Majeed", "Abdulmalik", "Abdul-Rehman", "Abdur", "Abdurraheem", "Abdur-Rahman", "Abdur-Rehmaan", "Abel", "Abhinav", "Abhisumant", "Abid", "Abir", "Abraham", "Abu", "Abubakar", "Ace", "Adain", "Adam", "Adam-James", "Addison", "Addisson", "Adegbola", "Adegbolahan", "Aden", "Adenn", "Adie", "Adil", "Aditya", "Adnan", "Adrian", "Adrien", "Aedan", "Aedin", "Aedyn", "Aeron", "Afonso", "Ahmad", "Ahmed", "Ahmed-Aziz", "Ahoua", "Ahtasham", "Aiadan", "Aidan", "Aiden", "Aiden-Jack", "Aiden-Vee", "Aidian", "Aidy", "Ailin", "Aiman", "Ainsley", "Ainslie"];
  
  var stepData = [
    {
      "title": "Main title 1",
      "substep": [
        {
          "title": "substep 1",
          "status": "complete",
        },
        {
          "title": "substep 2",
          "status": "complete",
        },

      ],
      "status": "complete",
    },
    {
      "title": "Main title 2",
      "substep": [
        {
          "title": "substep 1",
          "status": "complete",
        },
        {
          "title": "substep 2",
          "status": "complete",
        },
        {
          "title": "substep 3",
          "status": "active",
        },
        {
          "title": "substep 4",
          "status": "inactive",
        }
      ],
      "status": "active",
    },
    {
      "title": "Main title 3",
      "substep": [
        {
          "title": "substep 1",
          "status": "inactive",
        },
        {
          "title": "substep 2",
          "status": "inactive",
        },
      ],
      "status": "inactive",
    },
    {
      "title": "Main title 4",
      "substep": [
        {
          "title": "substep 1",
          "status": "inactive",
        },
        {
          "title": "substep 2",
          "status": "inactive",
        },
        {
          "title": "substep 3",
          "status": "inactive",
        },
        {
          "title": "substep 4",
          "status": "inactive",
        },
        {
          "title": "substep 5",
          "status": "inactive",
        },
        {
          "title": "substep 6",
          "status": "inactive",
        },
        {
          "title": "substep 7",
          "status": "inactive",
        }
      ],
      "status": "inactive",
    },
    {
      "title": "Main title 5",
      "substep": [
        {
          "title": "substep 1",
          "status": "inactive",
        },
        {
          "title": "substep 2",
          "status": "inactive",
        },
        {
          "title": "substep 3",
          "status": "inactive",
        },
        {
          "title": "substep 4",
          "status": "inactive",
        },
        {
          "title": "substep 5",
          "status": "inactive",
        },
        {
          "title": "substep 6",
          "status": "inactive",
        },
        {
          "title": "substep 7",
          "status": "inactive",
        },
        {
          "title": "substep 8",
          "status": "inactive",
        },
        {
          "title": "substep 9",
          "status": "inactive",
        },

      ],
      "status": "inactive",
    },
    {
      "title": "Main title 6",
      "substep": [
        {
          "title": "substep 1",
          "status": "inactive",
        },
        {
          "title": "substep 2",
          "status": "inactive",
        },
        {
          "title": "substep 3",
          "status": "inactive",
        },
        {
          "title": "substep 4",
          "status": "inactive",
        },
        {
          "title": "substep 5",
          "status": "inactive",
        },
        {
          "title": "substep 6",
          "status": "inactive",
        },
        {
          "title": "substep 7",
          "status": "inactive",
        },
        {
          "title": "substep 8",
          "status": "inactive",
        }
      ],
      "status": "inactive",
    },

  ];
  const TreeviewData = [
    {
      title: "main1",
      subtitleone: [
        {
          title: "hello",
        },
        {
          title: "Subtree with children",
          subtitletwo: [
            {
              title: "Subtree with children child",
            },
            {
              title: "Subtree with children child",
              subtitlethree: [
                {
                  title: "children child",
                },
                {
                  title: "children child",
                },
                {
                  title: "children child",
                }
              ]
            },
            {
              title: "Subtree with children child",
            },
            {
              title: "Subtree with children child",
            },
            {
              title: "Subtree with children child",
              subtitlethree: [
                {
                  title: "children child",
                },
                {
                  title: "children child",
                },
                {
                  title: "children child",
                }
              ]
            },
          ]
        },
        {
          title: "hello",
        }
      ]
    },
    {
      title: "main2",
      subtitleone: [
        {
          title: "hello",
        },
        {
          title: "Subtree with children",
          subtitletwo: [
            {
              title: "Subtree with children child",
            },
            {
              title: "Subtree with children child",
              subtitlethree: [
                {
                  title: "children child",
                },
                {
                  title: "children child",
                },
                {
                  title: "children child",
                }
              ]
            },
            {
              title: "Subtree with children child",
            },
            {
              title: "Subtree with children child",
            },
            {
              title: "Subtree with children child",
              subtitlethree: [
                {
                  title: "children child",
                },
                {
                  title: "children child",
                },
                {
                  title: "children child",
                }
              ]
            },
          ]
        },
        {
          title: "hello",
        },
        {
          title: "hello",
        }
      ]
    }
  ];
  var slotJSON = [
    {
      "date": "6/30/2022",
      "slots": [
        {
          "title": "Slot 1",
          "times": [
            {
              "id": "10:00",
              "title": "10:00 AM"
            },
            {
              "id": "11:00",
              "title": "11:00 AM"
            },
            {
              "id": "12:00",
              "title": "12:00 PM"
            },
            {
              "id": "12:30",
              "title": "12:30 PM"
            }
          ]
        },
        {
          "title": "Slot 2",
          "times": [
            {
              "id": "13:00",
              "title": "01:00 PM"
            },
            {
              "id": "14:00",
              "title": "02:00 PM"
            },
            {
              "id": "15:00",
              "title": "03:00 PM"
            },
            {
              "id": "13:30",
              "title": "01:30 PM"
            },
            {
              "id": "14:30",
              "title": "02:30 PM"
            },

            {
              "id": "15:30",
              "title": "03:30 PM"
            },
            {
              "id": "16:00",
              "title": "04:00 PM"
            },
            {
              "id": "16:30",
              "title": "04:30 PM"
            },

          ]
        }
      ]
    },

    {
      "date": "3/29/2022",
      "slots": [
        {
          "title": "Slot 1",
          "times": [
            {
              "id": "10:00",
              "title": "10:00 AM"
            },
            {
              "id": "11:00",
              "title": "11:00 AM"
            },
            {
              "id": "12:00",
              "title": "12:00 PM"
            }
          ]
        },
        {
          "title": "Slot 2",
          "times": [
            {
              "id": "13:00",
              "title": "01:00 PM"
            },
            {
              "id": "14:00",
              "title": "02:00 PM"
            },
            {
              "id": "15:00",
              "title": "03:00 PM"
            }
          ]
        }
      ]
    },
    {
      "date": "3/30/2022",
      "slots": [
        {
          "title": "Slot 1",
          "times": [
            {
              "id": "10:00",
              "title": "10:00 AM"
            },
            {
              "id": "11:00",
              "title": "11:00 AM"
            },
            {
              "id": "12:00",
              "title": "12:00 PM"
            }
          ]
        },
        {
          "title": "Slot 2",
          "times": [
            {
              "id": "13:00",
              "title": "01:00 PM"
            },
            {
              "id": "14:00",
              "title": "02:00 PM"
            },
            {
              "id": "15:00",
              "title": "03:00 PM"
            }
          ]
        }
      ]
    },
    {
      "date": "3/31/2022",
      "slots": [
        {
          "title": "Slot 1",
          "times": [
            {
              "id": "10:00",
              "title": "10:00 AM"
            },
            {
              "id": "11:00",
              "title": "11:00 AM"
            },
            {
              "id": "12:00",
              "title": "12:00 PM"
            }
          ]
        },
        {
          "title": "Slot 2",
          "times": [
            {
              "id": "13:00",
              "title": "01:00 PM"
            },
            {
              "id": "14:00",
              "title": "02:00 PM"
            },
            {
              "id": "15:00",
              "title": "30:00 PM"
            }
          ]
        }
      ]
    },

  ];
  const data = [
    {
      title: "A1",
      name: "title1",
    },
    {
      title: "A2",
      name: "title1",
    },
    {
      title: "A3",
      name: "title1",
    },
    {
      title: "A4",
      name: "title1",
    },
    {
      title: "A5",
      name: "title1",
    },
    {
      title: "A6",
      name: "title1",
    },
  ];
  const iconList = [
    { iconName: "Home", icon: <Home /> },
    { iconName: "Heart", icon: <Heart /> },
    { iconName: "Search", icon: <Search /> },
    { iconName: "Profile", icon: < Avatar /> },
    { iconName: "Notification", icon: < Bell /> },

  ];
  const onTreeElementClick = (item) => {
    if (item.children) {
      //TODO: just hacked this way. find best way to do this.
      // not changing address location of parent tree, tree has to reload.
      item.expanded = !item.expanded;
      setReload(!reload);
  } else {
      // item clicked
      setSelectedItem(item);
  }
   }
  const treeList =

  {
    "categories": [
      {
        "id": "buttons",
        "title": "Buttons"
      },
      {
        "children": [
          {
            "children": [
              {
                "id": "textboxes",
                "title": "Textboxes"
              },
              {
                "id": "passwordboxes",
                "title": "Passwordboxes"
              },
              {
                "id": "textareas",
                "title": "Textareas"
              }
            ],
            "id": "textinputs",
            "title": "Text Inputs"
          },
          {
            "children": [
              {
                "id": "radios",
                "title": "Radios"
              },
              {
                "id": "dropdowns",
                "title": "Dropdowns"
              },
              {
                "id": "chips",
                "title": "Chips"
              }
            ],
            "id": "singleselection",
            "title": "Single Selection"
          },
          {
            "children": [
              {
                "id": "checkboxes",
                "title": "Checkboxes"
              },
              {
                "id": "chips",
                "title": "Chips"
              }
            ],
            "id": "multiselection",
            "title": "Multi Selection"
          },
          {
            "id": "datetime pickers",
            "title": "Date Time Pickers"
          },
          {
            "id": "fileuploads",
            "title": "File Uploads"
          },
          {
            "id": "ratings",
            "title": "Ratings"
          },
          {
            "id": "sliders",
            "title": "Sliders"
          },
          {
            "id": "consentinputs",
            "title": "Consent Inputs"
          }
        ],
        "id": "forminputs",
        "title": "Form Inputs"
      },
      {
        "children": [
          {
            "id": "listviews",
            "title": "Listviews"
          },
          {
            "id": "tables",
            "title": "Tables"
          },
          {
            "id": "carousels",
            "title": "Carousels"
          }
        ],
        "id": "informationdisplay",
        "title": "Information Display"
      },
      {
        "children": [
          {
            "id": "progressindicators",
            "title": "Progress Indicators"
          },
          {
            "id": "timers",
            "title": "Timers"
          }
        ],
        "id": "indicators",
        "title": "Indicators"
      },
      {
        "children": [
          {
            "id": "breadcrumbs",
            "title": "Bread Crumbs"
          },
          {
            "id": "steppers",
            "title": "Steppers"
          },
          {
            "id": "tabs",
            "title": "Tabs"
          }
        ],
        "id": "navigations",
        "title": "Navigations"
      },
      {
        "children": [
          {
            "id": "chartjs",
            "title": "ChartJs"
          },
          {
            "id": "googlecharts",
            "title": "Google Charts"
          }
        ],
        "id": "charts",
        "title": "Charts"
      }
    ]
  }
  useEffect(()=>{
    setCategories(treeList.categories);

   }, []);


  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/" element={<CanvasArea />} />
        <Route exact path="/dragdrop" element={<TreeviewTrial data={TreeviewData} />} />
        {/* <Route exact path="/animation" element={<Animation data={TreeviewData} />} /> */}
        <Route exact path="/testinglist" element={<TestingList data={TreeviewData} />} />
        <Route exact path="/buttongroup" element={<ButtonGroup className={"sample"} list={["Movies", "Music", "Apps", "Sports", "Entertainment"]} />} />
        <Route exact path="/iconpointer" element={<IconPointer className={"sample"} list={iconList} />} />
        <Route exact path="/iconbackground" element={<IconBackground className={"sample"} list={iconList} />} />
        <Route exact path="/icontransition" element={<IconTransition className={"sample"} list={iconList} />} />
        <Route exact path="/iconunderline" element={<IconUnderLine className={"sample"} list={iconList} />} />
        <Route exact path="/msfnav" element={<MsfNavBar className={'sample'} list={iconList} />} />
        <Route exact path='/slotbook' element={<SlotBooking className={"sample"} days={15} slots={slotJSON} />} />
        <Route exact path='/uploadbtn' element={<MContainedUploadButton className={"sample"} />} />
        <Route exact path='/textuploadbtn' element={<MTextUploadButton className={"sample"} />} />
        <Route exact path='/otlnuploadbtn' element={<MOutLinedUploadButton className={"sample"} />} />
        <Route exact path='/navbar' element={<NavDiv className={"sample"} list={iconList} />} />
        <Route path="/pdfviewer" element={<PdfViewer className='sample' pdfUrl='https://www.pdfpdf.com/samples/Sample5.PDF' pagesToShow={10} showArrows={true} showPagination={true} />} />
        <Route path="/pdfslide" element={<PdfSlide className='sample' pdfUrl='https://www.pdfpdf.com/samples/Sample5.PDF' pagesToShow={10} showArrows={true} showPagination={true} />} />
        <Route exact path='/stepper' element={<Stepper className={"sample"} data={stepData} />} />
        <Route exact path='/test' element={<TestStepper className={"sample"} data={stepData} substepflag={false} />} />
        <Route exact path='/sample' element={<SampleVerticalStepper className={"sample"} steps={stepData} activeStepIndex={2} />} />
        {/* <Route exact path='/alist' element={<AnimatedList size={4} data={listData} />} /> 
        props for sample treee view
        elementGroup={selectedItem} list={serverfloderinfo} isEditing={false} onItemClick={onTreeElementClick}
        
        
        */
        
        }
        <Route exact path='/streeview' element={<TreeView list={categories} onItemClick={onTreeElementClick}  arrayList = {categories}/>} />
        <Route exact path='/treeview' element={<TreeviewTest data={TreeviewData} />} />
        <Route exact path='/dnd' element={<Dnd data={TreeviewData} />} />
        <Route exact path='/testlist' element={<TestList size={4} data={listData} className={"sample"} from={"top"} />} />
        <Route exact path='/stest' element={<TestSample className={"sample"} data={stepData} activeStepIndex={2} />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
