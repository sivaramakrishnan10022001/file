export interface LayoutCameraProps {
    makeDefault?: boolean
    manual?: boolean
    children?: React.ReactNode
}
