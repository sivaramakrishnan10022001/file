import React from 'react';

export default () => {
  return <div>Live demos of legacy libraries have been removed.</div>;

  // const Component = templates[template];

  // return (
  //   <StyledLiveContainer
  //     transformCode={isReactComponent ? undefined : injectRender}
  //     code={stripFirstReturn(children)}
  //     scope={{
  //       action,
  //       value,
  //       decay,
  //       keyframes,
  //       physics,
  //       spring,
  //       tween,
  //       listen,
  //       pointer,
  //       mouse,
  //       multitouch,
  //       multicast,
  //       composite,
  //       parallel,
  //       calc,
  //       easing,
  //       transform,
  //       styler,
  //       Component,
  //       id,
  //       autostart
  //     }}
  //     mountStylesheet={false}
  //     noInline={!isReactComponent}
  //   >
  //     <StyledLivePreview />
  //     <CodeContainer>
  //       <LiveEditorWrapper>
  //         <LiveEditorHeader>Live editor</LiveEditorHeader>
  //         <LiveEditor />
  //       </LiveEditorWrapper>
  //     </CodeContainer>
  //   </StyledLiveContainer>
  // );
};
