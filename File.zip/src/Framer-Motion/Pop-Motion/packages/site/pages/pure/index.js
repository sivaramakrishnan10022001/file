import PopmotionHomepage from '~/templates/Popmotion';

export default () => <PopmotionHomepage />;
