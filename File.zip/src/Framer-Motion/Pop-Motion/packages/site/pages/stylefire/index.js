import StylefireHomepage from '~/templates/Stylefire';

export default () => <StylefireHomepage />;
