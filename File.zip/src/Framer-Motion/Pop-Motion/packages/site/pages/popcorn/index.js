import PopcornHomepage from '~/templates/Popcorn';

export default () => <PopcornHomepage />;
