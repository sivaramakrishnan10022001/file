import PoseHomepage from '~/templates/Pose';

export default () => <PoseHomepage />;