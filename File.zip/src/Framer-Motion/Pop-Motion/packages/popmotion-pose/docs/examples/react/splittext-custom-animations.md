---
title: SplitText custom animations
description: Animate individual words and characters with Pose animations
category: react
---

# SplitText custom animations

Using the special properties provided by [React Pose Text](/pose/api/react-pose-text), you can create custom animations and staggers per word and character.

<CodeSandbox id="zzlr2p70mm" />
