---
title: SplitText
description: Animate individual words and characters with Pose animations
category: react
---

# SplitText

With [React Pose Text](/pose/api/react-pose-text), you can use Pose animations across individual words and characters.

<CodeSandbox id="4jzzvm1vz7" />
