---
title: 'Route transitions: React Router'
description: A live example of route transitions with Pose and React Router
category: react
---

# Route transitions: React Router

[Read the full tutorial](/pose/learn/route-transitions-react-router/)

<CodeSandbox height="600" id="wq324qk687" />
