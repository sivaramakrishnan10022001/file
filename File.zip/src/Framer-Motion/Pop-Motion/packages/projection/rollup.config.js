import generateConfig from "../../rollup-generate-config"
import pkg from "./package.json"

export default [...generateConfig(pkg)]
