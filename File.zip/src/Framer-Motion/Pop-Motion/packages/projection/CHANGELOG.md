# Changelog

Projection adheres to [Semantic Versioning](http://semver.org/).

## [2.0.0] Unreleased