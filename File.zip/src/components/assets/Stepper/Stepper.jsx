
import React from "react";
import './stepper.css';
class Stepper extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            key: '',
            classname: '',
        };
    }

    //===================================

    componentDidMount() {

    }
    //==================================
    clickedHeader(value) {
        if (!this.props.substepflag) {
            this.setState({
                key: value,
            });
        }
    }
    //==================================

    render() {
        var stepStatus, subStepStatus;
        return (
            <div className={"stepper-container " + this.props.className}>
                {this.props.data.map((row, key) => {
                    if (row.status === "complete") {
                        stepStatus = "complete";
                    }
                    else if (row.status === "active") {
                        stepStatus = "active";
                    }
                    else {
                        stepStatus = "inactive";
                    }
                    return (
                        <div class="steps-container" key={key}>
                            <div class={"head-container " + stepStatus} onClick={this.clickedHeader.bind(this, key)}>
                                <div className="head-pointer">
                                    {stepStatus === 'complete' ? <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 12" >
                                        <path
                                            d="M8.79,15.8,4.748,11.761,3.4,13.108,8.79,18.5,20.341,6.948,18.994,5.6Z"
                                            transform="translate(-3.4 -5.6)"
                                        />
                                    </svg> : <span>{key + 1}</span>
                                    }
                                    {stepStatus === 'inactive' ? <span>{key + 1}</span> : ''
                                    }
                                </div>
                                <div class="header" >{row.title}</div>
                                {stepStatus === 'active' ? <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 5 8" >
                                    <g transform="translate(0)">
                                        <g transform="translate(0 0)" >
                                            <path d="M56.306,7.855a.3.3,0,0,0,.453.072l4.354-3.641a.389.389,0,0,0,0-.58L56.759.072a.3.3,0,0,0-.453.072.394.394,0,0,0,.065.507L60.38,4,56.371,7.354A.386.386,0,0,0,56.306,7.855Z"
                                                transform="translate(-56.242 0)"
                                            />
                                        </g>
                                    </g>
                                </svg> : ''}
                            </div>
                            <div class={this.state.key === key ? "step-subheader active" : "step-subheader"} key={key}>
                                {
                                    row.substep.map((r1, k1) => {
                                        if (r1.status === 'complete') {
                                            subStepStatus = "complete";
                                        }
                                        else if (r1.status === 'active') {
                                            subStepStatus = "active";
                                        }
                                        else {
                                            subStepStatus = 'inactive';
                                        }
                                        return (
                                            <div className={"sub-title " + subStepStatus}>{console.log('r1.status(key case) =', subStepStatus, 'key = ', k1)}
                                                <div className="sub-pointer ">
                                                    {r1.status === 'complete' ? <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 12" >
                                                        <path
                                                            d="M8.79,15.8,4.748,11.761,3.4,13.108,8.79,18.5,20.341,6.948,18.994,5.6Z"
                                                            transform="translate(-3.4 -5.6)"
                                                        />
                                                    </svg> : <span>{k1 + 1}</span>}
                                                    {subStepStatus === 'active' ? <span>{k1 + 1}</span> : ''}
                                                </div>
                                                <div class="sub-header" key={k1}>{r1.title}
                                                    {subStepStatus === 'active' ? <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 5 8" >
                                                        <g transform="translate(0)">
                                                            <g transform="translate(0 0)" >
                                                                <path d="M56.306,7.855a.3.3,0,0,0,.453.072l4.354-3.641a.389.389,0,0,0,0-.58L56.759.072a.3.3,0,0,0-.453.072.394.394,0,0,0,.065.507L60.38,4,56.371,7.354A.386.386,0,0,0,56.306,7.855Z"
                                                                    transform="translate(-56.242 0)"
                                                                />
                                                            </g>
                                                        </g>
                                                    </svg> : ''}</div>

                                            </div>
                                        )
                                    })
                                }
                            </div>
                            <div class={this.props.substepflag === true ? "step-subheader active" : "step-subheader"} key={key}>
                                {
                                    row.substep.map((r1, k1) => {
                                        if (r1.status === "complete") {
                                            subStepStatus = "complete";
                                        }
                                        else if (r1.status === "active") {
                                            subStepStatus = "active";
                                        }
                                        else {
                                            subStepStatus = "inactive";
                                        }
                                        return (
                                            <div className={"sub-title " + subStepStatus}>{console.log('r1.status =', subStepStatus, 'key = ', k1)}
                                                <div className="sub-pointer">
                                                    {subStepStatus === 'complete' ? <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 12" >
                                                        <path
                                                            d="M8.79,15.8,4.748,11.761,3.4,13.108,8.79,18.5,20.341,6.948,18.994,5.6Z"
                                                            transform="translate(-3.4 -5.6)"
                                                        />
                                                    </svg> : <span>{k1 + 1}</span>}
                                                </div>
                                               
                                                <div class="sub-header" key={k1}>{r1.title}
                                                    {subStepStatus === 'active' ? <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 5 8" >
                                                        <g transform="translate(0)">
                                                            <g transform="translate(0 0)" >
                                                                <path d="M56.306,7.855a.3.3,0,0,0,.453.072l4.354-3.641a.389.389,0,0,0,0-.58L56.759.072a.3.3,0,0,0-.453.072.394.394,0,0,0,.065.507L60.38,4,56.371,7.354A.386.386,0,0,0,56.306,7.855Z"
                                                                    transform="translate(-56.242 0)"
                                                                />
                                                            </g>
                                                        </g>
                                                    </svg> : ''}</div>
                                            </div>
                                        )
                                    })
                                }
                            </div>
                        </div>)
                })}
            </div>)
    }
}

export default Stepper;