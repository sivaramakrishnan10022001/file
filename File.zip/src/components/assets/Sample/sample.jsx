import React from 'react';
import './sample.css';

export default class VerticalStepperWithSubStep extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            size: this.props.steps.length,
        }
    }
    //==============================================
    componentDidMount() {

    }

    // ==============================================

    getClassName(key) {
        if (key < this.props.activeStepIndex - 1) {
            return "stepper complete";
        } else if (key === this.props.activeStepIndex - 1) {
            return "stepper current";
        } else {
            return "stepper incomplete";
        }
    }

    // ==============================================

    render() {
        return (
            <div className={"m-vertical-stepper " + this.props.className}>

                {this.props.steps.map(function (row, key) {
                    return (
                        <span className={this.getClassName(key)} key={key}>

                            <div className='step-header'>
                                {key === 0 ? '' : <span className="line"></span>}



                                {key < this.props.activeStepIndex - 1 ?
                                    <span className="tick" >
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 12" >
                                            <path
                                                d="M8.79,15.8,4.748,11.761,3.4,13.108,8.79,18.5,20.341,6.948,18.994,5.6Z"
                                                transform="translate(-3.4 -5.6)"
                                            />
                                        </svg>
                                    </span>
                                    :
                                    <div className="tick" >
                                        <span> {key + 1}</span>

                                    </div>
                                }

                                <span className='label' >
                                    {row.title}
                                </span>

                                {key === this.props.activeStepIndex - 1 ?
                                    <span className="arrow">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 5 8" >
                                            <g transform="translate(0)">
                                                <g transform="translate(0 0)" >
                                                    <path d="M56.306,7.855a.3.3,0,0,0,.453.072l4.354-3.641a.389.389,0,0,0,0-.58L56.759.072a.3.3,0,0,0-.453.072.394.394,0,0,0,.065.507L60.38,4,56.371,7.354A.386.386,0,0,0,56.306,7.855Z"
                                                        transform="translate(-56.242 0)"
                                                    />
                                                </g>
                                            </g>
                                        </svg>
                                    </span>
                                    :
                                    ''
                                }
                            </div>
                            <div className='sub-steps'>
                                {row.substep.map((r1, k1) => {
                                    var status = r1.status;
                                    return (
                                        <div className='substep-header'>
                                            <span className='sub-line'></span>
                                            <div className={'substep-pointer ' + status}>
                                                {status === 'complete' ? <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 12" >
                                                    <path
                                                        d="M8.79,15.8,4.748,11.761,3.4,13.108,8.79,18.5,20.341,6.948,18.994,5.6Z"
                                                        transform="translate(-3.4 -5.6)"
                                                    />
                                                </svg> : <span>{k1 + 1}</span>}
                                            </div>

                                            {r1.title}
                                            {status === 'active' ? <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 5 8" >
                                                <g transform="translate(0)">
                                                    <g transform="translate(0 0)" >
                                                        <path d="M56.306,7.855a.3.3,0,0,0,.453.072l4.354-3.641a.389.389,0,0,0,0-.58L56.759.072a.3.3,0,0,0-.453.072.394.394,0,0,0,.065.507L60.38,4,56.371,7.354A.386.386,0,0,0,56.306,7.855Z"
                                                            transform="translate(-56.242 0)"
                                                        />
                                                    </g>
                                                </g>
                                            </svg> : ''}
                                        </div>)
                                })}
                            </div>

                        </span>

                    )

                }, this)}
            </div >
        );
    }
}
