import React from "react";
import './canvasarea.css';
class CanvasArea extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            className: "clear-button",
            flag: false,

        };
        this.clearCanvas = this.clearCanvas.bind(this);
        this.drawimage = this.drawimage.bind(this);
    }
    //===================================
    componentDidMount() {

        this.drawimage();
    }
    //================================================================
    drawimage() {
        var flag = true;
        var canvas = document.getElementById('sheet')
        var ctx = canvas.getContext('2d');
        var sketch = document.getElementById('area');
        var sketch_style = getComputedStyle(sketch);
        canvas.width = parseInt(sketch_style.getPropertyValue('width'));
        canvas.height = parseInt(sketch_style.getPropertyValue('height'));
        var mouse = { x: 0, y: 0 };
        var last_mouse = { x: 0, y: 0 };
        var onPaint = function () {
            flag = false;
            console.log('state', flag);
            ctx.beginPath();
            ctx.moveTo(last_mouse.x, last_mouse.y);
            ctx.lineTo(mouse.x, mouse.y);
            ctx.closePath();
            ctx.stroke();
        };
        canvas.addEventListener('mousemove', function (e) {

            last_mouse.x = mouse.x;
            last_mouse.y = mouse.y;
            mouse.x = e.pageX - this.offsetLeft;
            mouse.y = e.pageY - this.offsetTop;
        }, false);
        ctx.lineWidth = 1;
        ctx.lineJoin = 'round';
        ctx.lineCap = 'round';
        ctx.strokeStyle = 'black';
        canvas.addEventListener('mousedown', function (e) {
            flag = false;
            canvas.addEventListener('mousemove', onPaint, false);
        }, false);

        canvas.addEventListener('mouseup', function () {
            flag = false;
            canvas.removeEventListener('mousemove', onPaint, false);
        }, false);
        this.setState({
            clearFlag: flag,
        }, console.log('flag', this.state.clearFlag))
        this.setState({
            flag: !this.state.flag,
            className: "clear-button:active",
        });
        console.log('state', this.state.clearFlag);
    }
    //=================================================================
    clearCanvas() {
        var canvas = document.getElementById("sheet"), ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, 0, 250);
        canvas.width = 400;
        canvas.height = 300;
        ctx.fillRect(0, 0, 0, 250);
        this.setState({
            clearFlag: "clear-button",
            flag: !this.state.flag,
        });
        console.log('after clearing', this.state.flag);
    }
    //===================================================================
    createDownload() {
        const downloadURL = document.getElementById('sheet').toDataURL();
        document.getElementById('downloadLink').href = downloadURL;
    }

    //==================================

    render() {

        return (
            <div className="canvas-body">
                <div className="canvas-area" id="area">
                    < canvas className="canvas-sheet" id="sheet"></canvas>
                </div>
                {console.log('status', this.state.clearFlag)}

                <div onClick={this.clearCanvas} className={this.state.className}>
                    CLEAR
                </div>
                <div onClick={this.createDownload} >
                    <a id='downloadLink' download='myDrawing.png'>SAVE</a>
                </div>
            </div>)
    }
}

export default CanvasArea;