// const iconList = [
//     { iconName: "Home", icon: <Home /> },
//     { iconName: "Heart", icon: <Heart /> },
//     { iconName: "Search", icon: <Search /> },
//     { iconName: "Profile", icon: < Avatar /> },
//     { iconName: "Notification", icon: < Bell /> },

//   ];
//{<IconPointer className={"sample"} list={iconList} />}
import { ReactComponent as Pointer } from '../../../assets/icons/pointer.svg';
import React from 'react';
import './iconpointer.css';

class IconPointer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedTab: '',
        }
    }
    //  =========================================================================
    componentDidMount() {

    }
    //  =========================================================================
    setSelectedTab(value) {
        this.setState({
            selectedTab: value,
        })
    }
    // ===============================================================================
    render() {
        return (
            <div className={"iconpointerClass " + this.props.className}>
                <div className='iconpointerGroup'>
                    {this.props.list.map((row, key) => {
                        if (row === this.state.selectedTab) {
                            return <div className='iconpointer-unit active' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                <div className='icon'><div className='triangle'><Pointer /></div><div className='circle'></div>{row.icon}{row.iconName}</div><br /></div>
                        }
                        else {
                            return <div className='iconpointer-unit' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                <div className='icon'>{row.icon}{row.iconName} </div><br /></div>
                        }
                    })
                    }
                </div>
            </div>
        )
    }
}
export default IconPointer;