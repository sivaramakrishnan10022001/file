import React from "react";
import './TestList.css';
class TestList extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            value: '',
            items: [],
            className: '',
            flag: 0,
        };
        this.myRef = React.createRef();
        this.listRef = [];
    }

    //======================================

    componentDidMount() {

    }

    //======================================

    handleAdd() {
        var data = this.myRef;
        var temp_array = [];

        if (this.props.from === "top") {
            temp_array.push(data.value);
            for (var i = 0; i < this.state.items.length; i++) {
                temp_array.push(this.state.items[i]);
            }
        }
        else {
            temp_array = this.state.items;
            temp_array.push(data.value);

        }


        this.setState({
            items: temp_array,
        })
        this.listRef.className = 'list-item';
       
    }

    //======================================

    handleDelete() {
        let item = this.listRef;
        var temp_array = this.state.items;
        if (this.props.from === "top") {
        
           item.className+=" close"; 
          
            temp_array.shift();
           
        }
        else {
            temp_array.pop();
            
        }
    
       item.className = "list-item close";
      
         setTimeout(() => {
            item.className = "list-item";
            this.setState({
                items: temp_array,
            });
            
         }, 300);
       
        

    }

    //======================================

    handleReset() {
        console.log("Clickable")
        this.componentDidMount();
    }

    //======================================

    handleSort($list) {
        var i, content;
        const list = document.getElementById("animated-list");
        console.log('list type = ', list);
        for (i = 0; i < $list.children().length; i++) {
            // sort($('#numberlist'));
            content = $list.children('li:nth-child(' + i + ')').html();
            console.log('content = ', content);
            $list.children('li:nth-child(' + i + ')').attr('data-pos', content);
        }


    }

    //======================================

    render() {
        var index;
        if (this.props.from === "top") {
            if (this.state.items.length === 0) {
                index = -1;
            }
            else {
                index = 0;
            }

        }
        else {
            index = this.state.items.length - 1;
        }
        console.log(' index = ', index);

        return (
            <div style={{ padding: '20px' }} className={"list-class " + this.props.className}>
                <div className="input-box">
                    <input type="text" id="animatedlist-input" ref={(input) => this.myRef = input} placeholder="Enter Data Here"></input>
                </div>
                <div className="list-buttons">
                    <button onClick={this.handleAdd.bind(this)}>Add</button>
                    <button onClick={this.handleDelete.bind(this)}>Remove</button>
                    <button onClick={this.handleSort.bind(this)}>Sort</button>
                    <button onClick={this.handleReset.bind(this)}>Reset</button>
                </div>
                <div className="item-container">
                    <div className="list" id="animated-list">
                        {this.state.items.map((row, key) => {

                            return <div className={"list-item "} ref={key === index ? ref => this.listRef = ref : null} data={row} key={key} id={row}>
                                <div className="content">{row}</div>
                            </div>
                        })}
                    </div>
                </div>

            </div>
        )
    }
}

export default TestList;
