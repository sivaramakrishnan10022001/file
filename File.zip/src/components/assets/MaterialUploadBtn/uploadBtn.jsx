import React from "react";
import './uploadbtn.css';
export class MContainedUploadButton extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    }

    //===================================

    componentDidMount() {
    }
    //==================================

    //==================================

    render() {

        return (
            <div>
                <div className={"m-contained-upload-button " + this.props.className}>
                    <input type='file' className="upload-input" />
                    <span className="uploadbtn-text">UPLOAD</span>
                    {/* <RippleEffect className="ripple" /> */}
                </div>
            </div>
        )
    }
}

export class MOutLinedUploadButton extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    }

    //===================================

    componentDidMount() {
    }


    //==================================

    render() {

        return (
            <div className={"m-outlined-upload-button " + this.props.className}>
                <input type='file' className="upload-input" />
                <span className="uploadbtn-text">UPLOAD</span>
                {/* <RippleEffect className="ripple" /> */}

            </div>
        )
    }
}

export class MTextUploadButton extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
        };

    }

    //===================================

    componentDidMount() {
    }
   
    //==================================

    render() {

        return (
            <div className={"m-text-upload-button " + this.props.className}>
                <input type='file' className="upload-input" />
                <span className="uploadbtn-text">UPLOAD</span>
                {/* <RippleEffect className="ripple" /> */}

            </div>
        )
    }
}

