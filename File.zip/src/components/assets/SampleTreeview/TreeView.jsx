// "categories": [
//     {
//       "id": "buttons",
//       "title": "Buttons"
//     },
//     {
//       "children": [
//         {
//           "children": [
//             {
//               "id": "textboxes",
//               "title": "Textboxes"
//             },
//             {
//               "id": "passwordboxes",
//               "title": "Passwordboxes"
//             },
//             {
//               "id": "textareas",
//               "title": "Textareas"
//             }
//           ],
//           "id": "textinputs",
//           "title": "Text Inputs"
//         },
//         {
//           "children": [
//             {
//               "id": "radios",
//               "title": "Radios"
//             },
//             {
//               "id": "dropdowns",
//               "title": "Dropdowns"
//             },
//             {
//               "id": "chips",
//               "title": "Chips"
//             }
//           ],
//           "id": "singleselection",
//           "title": "Single Selection"
//         },
//         {
//           "children": [
//             {
//               "id": "checkboxes",
//               "title": "Checkboxes"
//             },
//             {
//               "id": "chips",
//               "title": "Chips"
//             }
//           ],
//           "id": "multiselection",
//           "title": "Multi Selection"
//         },
//         {
//           "id": "datetime pickers",
//           "title": "Date Time Pickers"
//         },
//         {
//           "id": "fileuploads",
//           "title": "File Uploads"
//         },
//         {
//           "id": "ratings",
//           "title": "Ratings"
//         },
//         {
//           "id": "sliders",
//           "title": "Sliders"
//         },
//         {
//           "id": "consentinputs",
//           "title": "Consent Inputs"
//         }
//       ],
//       "id": "forminputs",
//       "title": "Form Inputs"
//     },
//     {
//       "children": [
//         {
//           "id": "listviews",
//           "title": "Listviews"
//         },
//         {
//           "id": "tables",
//           "title": "Tables"
//         },
//         {
//           "id": "carousels",
//           "title": "Carousels"
//         }
//       ],
//       "id": "informationdisplay",
//       "title": "Information Display"
//     },
//     {
//       "children": [
//         {
//           "id": "progressindicators",
//           "title": "Progress Indicators"
//         },
//         {
//           "id": "timers",
//           "title": "Timers"
//         }
//       ],
//       "id": "indicators",
//       "title": "Indicators"
//     },
//     {
//       "children": [
//         {
//           "id": "breadcrumbs",
//           "title": "Bread Crumbs"
//         },
//         {
//           "id": "steppers",
//           "title": "Steppers"
//         },
//         {
//           "id": "tabs",
//           "title": "Tabs"
//         }
//       ],
//       "id": "navigations",
//       "title": "Navigations"
//     },
//     {
//       "children": [
//         {
//           "id": "chartjs",
//           "title": "ChartJs"
//         },
//         {
//           "id": "googlecharts",
//           "title": "Google Charts"
//         }
//       ],
//       "id": "charts",
//       "title": "Charts"
//     }
//   ]
// {<TreeView list={categories} onItemClick={onTreeElementClick}  arrayList = {categories}/>}

import React, { useState, useEffect, useRef } from 'react';
import EyeCloseIcon from '../../../assets/icons/eyecloseicon.svg';
import MinusIcon from '../../../assets/icons/minusicon.svg';
import PlusIcon from '../../../assets/icons/plusicon.svg';
import EyeOpenIcon from '../../../assets/icons/eyeopenicon.svg';
import FileJsxIcon from '../../../assets/icons/jsxicon.svg';
import FolderIcon from '../../../assets/icons/folder.svg';
import FileIcon from '../../../assets/icons/file.svg';
import MoreIcon from '../../../assets/icons/more.svg';
import { sortableContainer, sortableElement, sortableHandle } from '../react-sortable-hoc/react-sortable-hoc';
import { arrayMove } from '../react-sortable-hoc/utils';
import './treeviewstyle.css';

export const TreeView = (props) => {

    const [flag, setFlag] = useState(0);
    const [indx, setIndex] = useState(null);
    const [itemID, setItemId] = useState(null);
    const [dropIndex, setDropIndex] = useState(null);
    const [tempObject, setTempObject] = useState({});
    const [editingRow, setEditingRow] = useState(false);
    const [treeList, setTreeList] = useState([]);
    const [popupCoordinates, setPopupCoordinates] = useState({});
    const [popupList, setPopupList] = useState([]);
    const [popUpRow, setPopUpRow] = useState("");
    const [selectedRowEdit, setSelectedRowEdit] = useState(false);
    const popupdata = ["Rename", "Delete"];
    const [reload, setReload] = useState(false);
    const [className, setClassName] = useState(null);
    const contextMenu = useRef(null);
    const [dummyList, setDummyList] = useState([]);
    const [isEditing, setIsEditing] = useState(false);
    const [draggedObject, setDraggedObject] = useState({
        children: [],
        id: '',
        title: ''
    });
    const [reloads, setReloads] = useState(false)
    const dragItem = useRef();
    const dragOverItem = useRef();
    useEffect(() => {
        setPopupList(popupdata);
        setTreeList(props.list);
        setDummyList(props.arrayList);

    }, [props.list]);
    var drop2 = null;
    const DragHandle = sortableHandle(() =>
        <span className='handle'>
            <svg stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><g><path fill="none" d="M0 0h24v24H0z"></path><path d="M11 11V5.828L9.172 7.657 7.757 6.243 12 2l4.243 4.243-1.415 1.414L13 5.828V11h5.172l-1.829-1.828 1.414-1.415L22 12l-4.243 4.243-1.414-1.415L18.172 13H13v5.172l1.828-1.829 1.415 1.414L12 22l-4.243-4.243 1.415-1.414L11 18.172V13H5.828l1.829 1.828-1.414 1.415L2 12l4.243-4.243 1.414 1.415L5.828 11z"></path></g></svg>
        </span>
    );

    const searchIndex = (list, row, source) => {

        list.map((rw, ky) => {

            if (rw.id === row.id) {
                deleteDraggedItem(dummyList, source);
                deleteDraggedItem(treeList, source);
                rw.children.unshift(source);
                setReload(!reload);
            }
            else if (rw.children) {
                searchIndex(rw.children, row, source);
            }
        })
        console.log('tree list', treeList);
        console.log('dummy list', dummyList);

        setTreeList(treeList);
        setReload(!reload);

    }
    const deleteDraggedItem = (list, source) => {
        setReload(!reload);
        for (const [i, obj] of list.entries()) {
            if (obj.id === source.id) {
                list.splice(i, 1);
                setReload(!reload);
                setDummyList(dummyList);
            }
            if (obj.children) {
                deleteDraggedItem(obj.children, source);
            }
            setReload(!reload);
        }
        setReload(!reload);
    }

    const SortableItem = sortableElement(({ row, className, indx, key, index }) => (
        <div className={"c-container " + className}>
            <DragHandle />

        </div>

        // **********************************************************************************************

    ));
    const showPopUp = (e, row) => {
        e.stopPropagation();
        const coordinates = e.target.getBoundingClientRect();
        setPopupCoordinates({ top: coordinates.top + 20, left: coordinates.left - 100 });

        setEditingRow(true);
        setPopUpRow(row);

        setTimeout(() => {
            if (contextMenu.current)
                contextMenu.current.focus();
        }, 100);
    };

    const onPopupOptionClick = (option, row) => {
        if (option.trim().toLowerCase() === "rename") {
            setEditingRow(false);
            setSelectedRowEdit(true);
        } else {
            onDeleteClick(row);
        }
    }

    const onInputChange = (e, row) => {
        row.title = e.target.value;
        row.id = e.target.value.trim().toLowerCase();
        setReload(!reload);
    }

    const onInputBlur = () => {
        setSelectedRowEdit(false);
        setPopUpRow("");
        setEditingRow(false);
    }

    const onDeleteClick = (row) => {
        var list = treeList;
        var indx = list.findIndex(i => i.id === row.id);
        if (indx !== -1) {
            list.splice(indx, 1);
        }
        setEditingRow(false);
        setReload(!reload);
    }

    const onAddFolderClick = (e, row) => {
        e.stopPropagation();
        const folderStructure = {
            "children": [],
            "id": "",
            "title": "",
        }
        row.children.unshift(folderStructure);
        setReload(!reload);
    }

    const onAddFileClick = (e, row) => {
        e.stopPropagation();
        const fileStructure = {
            "id": "",
            "title": "",
        }
        var indx = row.children.findIndex((rw) => !rw.children);
        row.children.splice(indx, 0, fileStructure);
        setReload(!reload);
    }

    const onNewFileFolderAdd = (e, row) => {
        row.title = e.target.value;
        row.id = e.target.value.trim().toLowerCase();
        setPopUpRow(row);
        setSelectedRowEdit(true);
    }

    const onKeyboardClick = (e, row) => {
        if (e.keyCode === 27 || e.keyCode === 46) {
            // escape or delete key press
            onDeleteClick(row);
        } else if (e.keyCode === 13) {
            // enter key press
            onInputBlur();
        }
    }
    const dragStart = (e, row) => {
        e.stopPropagation();
        e.dataTransfer.setData("source", JSON.stringify(row));
        //console.log('on drag', treeList);

    }
    const onTargetEnter = (e, row) => {

    }
    const onTargetOver = (e, row) => {
        e.stopPropagation();
        e.preventDefault();
    }
    const onTargetLeave = (e, row) => {

    }
    const onTargetDrop = (e, row) => {
        e.stopPropagation();
        e.preventDefault();
        var source = e.dataTransfer.getData("source");

        searchIndex(dummyList, row, JSON.parse(source));
        setDummyList(dummyList);
        console.log('dummy list = ', dummyList);

    }
    const onTargetEnd = (e, row) => {
        setReloads(() => !reloads)
    }

    return (
        <div className="tree-view">

            {editingRow &&
                <div ref={contextMenu} className='tree-popup-container' style={{ position: "fixed", display: editingRow ? "block" : "none", ...popupCoordinates }}
                    tabIndex="-1" onBlur={() => setEditingRow(false)}>
                    {popupList.map((row, key) =>
                        <div key={key} className='popup-content' onClick={() => onPopupOptionClick(row, popUpRow)}>{row}</div>
                    )}
                </div>}

            {treeList.map((row, key) => {

                if (row.children)
                    var indx = row.children.findIndex((rw) => rw.id === "");
                return (
                    <div key={key} className="tree-item" >

                        {row.children ?

                            <div className={row.expanded || indx > -1 ? "folder expanded" : "folder"}>
                                <div className={popUpRow === row && !selectedRowEdit ? "title active" : "title"}
                                    onClick={() => props.onItemClick(row)}
                                    onDragStart={(e) => dragStart(e, row)}
                                    onDragEnter={(e) => onTargetEnter(e, row)}
                                    onDragOver={(e) => onTargetOver(e, row)}
                                    onDragLeave={(e) => onTargetLeave(e, row)}
                                    onDrop={(e) => onTargetDrop(e, row)}
                                    onDragEnd={(e) => onTargetEnd(e, row)}

                                    draggable>
                                    <div className='name'>
                                        <img className='caret' src={row.expanded || indx > -1 ? MinusIcon : PlusIcon} alt="" />
                                        {row.expanded || indx > -1 ?
                                            <img className='icon' src={EyeOpenIcon} alt="" />
                                            :
                                            <img className='icon' src={EyeCloseIcon} alt="" />
                                        }
                                        {row === popUpRow && selectedRowEdit
                                            ?
                                            <input className='rename-box' type="text"
                                                onChange={(e) => onInputChange(e, row)} value={row.title} autoFocus={true}
                                                onKeyUp={(e) => onKeyboardClick(e, row)} onBlur={() => onInputBlur()} />
                                            :
                                            row.id === "" ? <input className='rename-box' type="text"
                                                onChange={(e) => onNewFileFolderAdd(e, row)} value={row.title} autoFocus={true}
                                                onKeyUp={(e) => onKeyboardClick(e, row)} onBlur={() => onDeleteClick(row)} />
                                                :
                                                <div>{row.title}</div>
                                        }
                                    </div>
                                    {props.isEditing ?
                                        <div className='options'>
                                            <button type="button" className='sb-btn' > <img className='icon' src={FolderIcon} alt="" onClick={(e) => onAddFolderClick(e, row)} /> </button>
                                            <button type="button" className='sb-btn' > <img className='icon' src={FileIcon} alt="" onClick={(e) => onAddFileClick(e, row)} /> </button>
                                            <button type="button" className='sb-btn' > <img className='icon' src={MoreIcon} alt="" onClick={(e) => showPopUp(e, row)} /> </button>
                                        </div>
                                        :
                                        ''
                                    }
                                </div>
                                {row.expanded || indx > -1 ?
                                    <div className="content">
                                        <TreeView list={row.children} selectedItem={props.selectedItem} isEditing={props.isEditing} onItemClick={props.onItemClick} arrayList={dummyList} />
                                    </div>
                                    :
                                    ''
                                }
                            </div>

                            :
                            <div className={props.selectedItem === row ? "item selected" : "item"}
                                onDragStart={(e) => dragStart(e, row)}
                                onDragEnter={(e) => onTargetEnter(e, row)}
                                onDragOver={(e) => onTargetOver(e, row)}
                                onDragLeave={(e) => onTargetLeave(e, row)}
                                onDrop={(e) => onTargetDrop(e, row)}
                                onDragEnd={(e) => onTargetEnd(e, row)}

                                draggable
                            >
                                <div className="title" onClick={() => props.onItemClick(row)} >
                                    <div className='name'>
                                        <img className='icon' src={FileJsxIcon} alt="" />
                                        {row === popUpRow && selectedRowEdit
                                            ?
                                            <input className='rename-box' type="text"
                                                onChange={(e) => onInputChange(e, row)} value={row.title} autoFocus={true}
                                                onKeyUp={(e) => onKeyboardClick(e, row)} onBlur={() => onInputBlur()} />
                                            :
                                            row.id === "" ? <input className='rename-box' type="text"
                                                onChange={(e) => onNewFileFolderAdd(e, row)} value={row.title} autoFocus={true}
                                                onKeyUp={(e) => onKeyboardClick(e, row)} onBlur={() => onDeleteClick(row)} />
                                                :
                                                <div>{row.title}</div>
                                        }
                                    </div>
                                    {props.isEditing ?
                                        <div className='options'>
                                            <button type="button" className='sb-btn' > <img className='icon' src={MoreIcon} alt="" onClick={(e) => showPopUp(e, row)} /> </button>
                                        </div>
                                        :
                                        ''
                                    }
                                </div>
                            </div>
                        }
                    </div>
                    //<SortableItem key={`item-${row}`} className="sample" index={key} value={row} ind={indx}/>
                )
            })}

        </div>
    )
}
