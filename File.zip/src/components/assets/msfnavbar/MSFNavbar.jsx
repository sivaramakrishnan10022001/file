// const iconList = [
//     { iconName: "Home", icon: <Home /> },
//     { iconName: "Heart", icon: <Heart /> },
//     { iconName: "Search", icon: <Search /> },
//     { iconName: "Profile", icon: < Avatar /> },
//     { iconName: "Notification", icon: < Bell /> },

//   ];
//{<MsfNavBar className={'sample'} list={iconList} />}
import React from 'react';
import Logo from '../../../assets/images/msflogo.png';
import './msfnavbar.css';
import { ReactComponent as HamburgerIcon } from '../../../assets/icons/hamburgericon.svg';
import { ReactComponent as Close } from '../../../assets/icons/close.svg';
class MsfNavBar extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedTab: '',
            isclicked: false,
        }
        this.sidebarTab = this.sidebarTab.bind(this);
    }
    //  =========================================================================
    componentDidMount() {

    }
    //  =========================================================================
    sidebarTab() {
        this.setState({
            isClicked: !this.state.isClicked,
        })
    }

    //  =========================================================================
    setSelectedTab(value) {
        this.setState({
            selectedTab: value,
        })
    }
    // ===============================================================================

    render() {
        return (
            <div className={"msfnavClass " + this.props.className}>
                <div className='msfnavGroup'><div className='logo'><img src={Logo} /></div>
                    {this.props.list.map((row, key) => {
                        if (row === this.state.selectedTab) {
                            return <div className='msfnav-unit active' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                <div className='msfnav' title={row.iconName}></div><div className='text'>{row.iconName}</div> </div>
                        }
                        else {
                            return <div className='msfnav-unit' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                <div className='msfnav' title={row.iconName}><div className='text'>{row.iconName}</div> </div>  </div>
                        }
                    })
                    }
                    <div className='hamburgericon' onClick={this.sidebarTab}>
                        {
                            this.state.isClicked ? <Close /> : <HamburgerIcon />
                        }
                    </div>
                </div>
                <div className={this.state.isClicked ? "sidebar active" : "sidebar"}>
                    <ul>
                        {this.props.list.map((row, key) => {
                            if (row === this.state.selectedTab) {
                                return (
                                    <div className='sidebarTab active' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                        <li className='text' title={row.iconName}>{row.iconName}</li>
                                    </div>
                                )
                            }
                            else {
                                return (
                                    <div className='sidebarTab' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                        <li className='text' title={row.iconName}>{row.iconName}</li>
                                    </div>
                                )
                            }
                        })}
                    </ul>
                </div>
            </div>
        )
    }
}
export default MsfNavBar;