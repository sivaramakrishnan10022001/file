// const iconList = [
//     { iconName: "Home", icon: <Home /> },
//     { iconName: "Heart", icon: <Heart /> },
//     { iconName: "Search", icon: <Search /> },
//     { iconName: "Profile", icon: < Avatar /> },
//     { iconName: "Notification", icon: < Bell /> },

//   ];
//{<IconUnderLine className={"sample"} list={iconList} />}
import React from 'react';
import './iconunderline.css';

class IconUnderLine extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedTab: '',
        }
    }
    //  =========================================================================
    componentDidMount() {

    }

    setSelectedTab(value) {
        this.setState({
            selectedTab: value,
        })
    }


    // ===============================================================================

    render() {
        return (

            <div className={"icon-underline-Class " + this.props.className}>
                <div className='icon-underline-Group'>
                    {this.props.list.map((row, key) => {
                        if (row === this.state.selectedTab) {
                            return <div className='icon-underline-unit active' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                <div className='icon'>{row.icon}</div></div>
                        }
                        else {
                            return <div className='icon-underline-unit' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                <div className='icon'>{row.icon} </div> </div>
                        }
                    })
                    }
                    
                </div>
            </div>
        )
    }

}
export default IconUnderLine;