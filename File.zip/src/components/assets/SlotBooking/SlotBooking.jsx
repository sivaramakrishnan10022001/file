// var slotJSON = [
//     {
//       "date": "3/28/2022",
//       "slots": [
//         {
//           "title": "Slot 1",
//           "times": [
//             {
//               "id": "10:00",
//               "title": "10:00 AM"
//             },
//             {
//               "id": "11:00",
//               "title": "11:00 AM"
//             },
//             {
//               "id": "12:00",
//               "title": "12:00 PM"
//             },
//             {
//               "id": "12:30",
//               "title": "12:30 PM"
//             }
//           ]
//         },
//         {
//           "title": "Slot 2",
//           "times": [
//             {
//               "id": "13:00",
//               "title": "01:00 PM"
//             },
//             {
//               "id": "14:00",
//               "title": "02:00 PM"
//             },
//             {
//               "id": "15:00",
//               "title": "03:00 PM"
//             },
//             {
//               "id": "13:30",
//               "title": "01:30 PM"
//             },
//             {
//               "id": "14:30",
//               "title": "02:30 PM"
//             },

//             {
//               "id": "15:30",
//               "title": "03:30 PM"
//             },
//             {
//               "id": "16:00",
//               "title": "04:00 PM"
//             },
//             {
//               "id": "16:30",
//               "title": "04:30 PM"
//             },

//           ]
//         }
//       ]
//     },

//     {
//       "date": "3/29/2022",
//       "slots": [
//         {
//           "title": "Slot 1",
//           "times": [
//             {
//               "id": "10:00",
//               "title": "10:00 AM"
//             },
//             {
//               "id": "11:00",
//               "title": "11:00 AM"
//             },
//             {
//               "id": "12:00",
//               "title": "12:00 PM"
//             }
//           ]
//         },
//         {
//           "title": "Slot 2",
//           "times": [
//             {
//               "id": "13:00",
//               "title": "01:00 PM"
//             },
//             {
//               "id": "14:00",
//               "title": "02:00 PM"
//             },
//             {
//               "id": "15:00",
//               "title": "03:00 PM"
//             }
//           ]
//         }
//       ]
//     },
//     {
//       "date": "3/30/2022",
//       "slots": [
//         {
//           "title": "Slot 1",
//           "times": [
//             {
//               "id": "10:00",
//               "title": "10:00 AM"
//             },
//             {
//               "id": "11:00",
//               "title": "11:00 AM"
//             },
//             {
//               "id": "12:00",
//               "title": "12:00 PM"
//             }
//           ]
//         },
//         {
//           "title": "Slot 2",
//           "times": [
//             {
//               "id": "13:00",
//               "title": "01:00 PM"
//             },
//             {
//               "id": "14:00",
//               "title": "02:00 PM"
//             },
//             {
//               "id": "15:00",
//               "title": "03:00 PM"
//             }
//           ]
//         }
//       ]
//     },
//     {
//       "date": "3/31/2022",
//       "slots": [
//         {
//           "title": "Slot 1",
//           "times": [
//             {
//               "id": "10:00",
//               "title": "10:00 AM"
//             },
//             {
//               "id": "11:00",
//               "title": "11:00 AM"
//             },
//             {
//               "id": "12:00",
//               "title": "12:00 PM"
//             }
//           ]
//         },
//         {
//           "title": "Slot 2",
//           "times": [
//             {
//               "id": "13:00",
//               "title": "01:00 PM"
//             },
//             {
//               "id": "14:00",
//               "title": "02:00 PM"
//             },
//             {
//               "id": "15:00",
//               "title": "30:00 PM"
//             }
//           ]
//         }
//       ]
//     },

//   ];
//{<SlotBooking className={"sample"} days={15} slots={slotJSON} />} 
import React from "react";
import './slotbooking.css';
class SlotBooking extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            today: new Date(),
            days: this.props.days,
            dayArray: [],
            selectedDate: new Date(),
            slotData: this.props.slots,
            slotFlag: '',
            selectedSlot: '',
            index: null,
            slotIndex: null,
        };

    }

    //===================================

    componentDidMount() {
        var currenDate = new Date();
        currenDate.setHours(0, 0, 0, 0);
        var index = currenDate.getDay();
        this.setState({
            selectedDate: currenDate,
            index: index - 1,
        });
    }
    //==================================
    setSelectedDate(value) {
        var index = value.getDay() - 1;
        if (index === -1) {
            index = 6;
        }
        this.setState({
            selectedDate: value,
            index: index,
        });
    }
    //==================================
    setSelectedSlot = (value, k1, row1Item) => {
        let data = Object.assign([], row1Item);
        data = data.map((index, key) => {
            if (k1 === key) {
                index.isOpen = !index.isOpen;
            }
            return index;
        })
        this.setState({
            selectedSlot: value,
            slotIndex: k1,
            row1Item: data,
        })
    }
    //==================================
    getWeekDays = (locale) => {
        var baseDate = new Date(Date.UTC(2017, 0, 2)); // just a Monday
        var weekDays = [];
        for (var i = 0; i < 7; i++) {
            weekDays.push(baseDate.toLocaleDateString(locale, { weekday: 'long' }));
            baseDate.setDate(baseDate.getDate() + 1);
        }
        return weekDays;
    }
    //==================================

    render() {
        var days = [];
        var weekDays = this.getWeekDays('en-US');
        var today = new Date();
        today.setHours(0, 0, 0, 0);
        for (var i = 0; i < this.state.days; i++) {
            var day = new Date();
            day.setDate(this.state.today.getDate() + i);
            day.setHours(0, 0, 0, 0);
            days.push(day);
        }
        var weeks = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        var selecteddate = this.state.today;
        selecteddate.setHours(0, 0, 0, 0);
        return (
            <div className={"slot-container " + this.props.className}>
                Schedule time for video call
                <div className="booking-body">
                    <div className="days-box">
                        {days.map((row, key) => {
                            var day = row.getDay() - 1;
                            if (day == -1) {
                                weeks[day] = "Sun";
                            }
                            var temDate = row.toLocaleDateString("en-US");
                            return (
                                <div key={key} className={temDate === this.state.selectedDate.toLocaleDateString("en-US") ? 'day-box active' : 'day-box'} onClick={this.setSelectedDate.bind(this, row, weeks[day])}>
                                    <div className="date">{row.getDate()}</div>
                                    <div className="week">
                                        {weeks[day]}
                                    </div>
                                    {temDate === this.state.today.toLocaleDateString("en-US") ?
                                        <span className={temDate === this.state.today.toLocaleDateString("en-US") && this.state.today.toLocaleDateString("en-US") === this.state.selectedDate.toLocaleDateString("en-US") ? 'title-class active' : 'title-class'} id='today-title' >
                                            Today</span> : ""}
                                </div>
                            )
                        })
                        }
                    </div>
                    <div className="slot-box">
                        {
                            this.props.slots.map((row, key) => {
                                if (row.date === this.state.selectedDate.toLocaleDateString("en-US")) {
                                    return (
                                        <div key={key} className='slot-body'>
                                            {
                                                row.slots.map((row1, key1) => {
                                                    return (
                                                        <div className="slot" key={key1}>
                                                            <div className="slot-title"> {row1.title}</div>
                                                            <div className="slot-timer-body">
                                                                {
                                                                    row1.times.map((r1, k1) => {
                                                                        return (
                                                                            <div key={k1} className={this.state.selectedSlot === r1.title ? 'slot-time active' : 'slot-time'} onClick={() => this.setSelectedSlot(r1.title, k1, row1.times)}>
                                                                                {r1.title}
                                                                            </div>
                                                                        )
                                                                    })
                                                                }
                                                            </div>
                                                        </div>
                                                    )
                                                })
                                            }
                                        </div>
                                    )
                                }
                            })
                        }
                    </div>
                </div>
                <div className={this.state.selectedSlot === '' ? "booked-container" : "booked-container active"}>
                    <div className="book-content">
                        <div className="booked-icon">
                            <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10zM9 14H7v-2h2v2zm4 0h-2v-2h2v2zm4 0h-2v-2h2v2zm-8 4H7v-2h2v2zm4 0h-2v-2h2v2zm4 0h-2v-2h2v2z"></path></svg>
                        </div>
                        <div className="booked-text">
                            <div className="first-title">Selected Date &amp; Time :</div>
                            <div className="second-title">{weekDays[this.state.index]}, {this.state.selectedDate.getDate()} {this.state.selectedDate.toLocaleString('default', { month: 'long' })} - {this.state.selectedSlot}</div></div>
                    </div>
                    <div className="confirm-button">
                        <div className="c-button">confirm booking</div>
                    </div>
                </div>
            </div>)
    }
}

export default SlotBooking;