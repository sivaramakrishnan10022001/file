import React from 'react';
// import Logo from '../../assets/images/msflogo.png';
import Logo from '../../../assets/images/msflogo.png';
import './navbar.css';

class NavDiv extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedTab: '',
        }
    }
    //  =========================================================================
    componentDidMount() {

    }
    //  =========================================================================
    setSelectedTab(value) {
        this.setState({
            selectedTab: value,
        })
    }
    // ===============================================================================

    render() {
        return (
            <div className={"nav-Class " + this.props.className}>
                <div className='nav-Group'><div className='logo'><img src={Logo} /></div>
                    {this.props.list.map((row, key) => {
                        if (row === this.state.selectedTab) {
                            return <div className='nav-unit active' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                <div className='nav' title={row.iconName}><div className='icon'>{row.icon}</div></div> <div className='text'>{row.iconName}</div> </div>
                        }
                        else {
                            return <div className='nav-unit' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                <div className='nav' title={row.iconName}><div className='icon'>{row.icon}</div><div className='text'>{row.iconName}</div> </div> </div>
                        }
                    })
                    }
                </div>
            </div>
        )
    }

}
export default NavDiv;