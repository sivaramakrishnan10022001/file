//{<ButtonGroup className={"sample"} list={["Movies", "Music", "Apps", "Sports", "Entertainment"]} />}
import React from 'react';
import './ButtonGroupDiv.css';

class ButtonGroup extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedTab: '',
        }
    }
    //  =========================================================================
    componentDidMount() {

    }
    //  =========================================================================
    setSelectedTab(value) {
        this.setState({
            selectedTab: value,
        })
    }
    // ===============================================================================

    render() {
        return (
            <div className={"button-group-mainclass " + this.props.className}>
                <div className='btn-group'>
                    {this.props.list.map((row, key) => {
                        if (row === this.state.selectedTab) {
                            return <div className='button-unit active' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                <div >{row}</div>  </div>
                        }
                        else {
                            return <div className='button-unit' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                <div >{row}</div>  </div>
                        }
                    })
                    }
                </div>
            </div>
        )
    }
}
export default ButtonGroup;