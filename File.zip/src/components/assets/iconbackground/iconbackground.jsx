// const iconList = [
//     { iconName: "Home", icon: <Home /> },
//     { iconName: "Heart", icon: <Heart /> },
//     { iconName: "Search", icon: <Search /> },
//     { iconName: "Profile", icon: < Avatar /> },
//     { iconName: "Notification", icon: < Bell /> },

//   ];

//{<IconBackground className={"sample"} list={iconList} />}
import React from 'react';
import './iconbackground.css';

class IconBackground extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedTab: '',
        }
    }
    //  =========================================================================
    componentDidMount() {

    }

    setSelectedTab(value) {
        this.setState({
            selectedTab: value,
        })
    }


    // ===============================================================================

    render() {
        return (

            <div className={"iconbgClass " + this.props.className}>
                <div className='iconbgGroup'>
                    {this.props.list.map((row, key) => {
                        if (row === this.state.selectedTab) {
                            return <div className='iconbg-unit active' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                <div className='icon'>{row.icon}{row.iconName}</div></div>
                        }
                        else {
                            return <div className='iconbg-unit' key={key} onClick={this.setSelectedTab.bind(this, row)}>
                                <div className='icon'>{row.icon}{row.iconName} </div> </div>
                        }
                    })
                    }
                    
                </div>
            </div>
        )
    }

}
export default IconBackground;