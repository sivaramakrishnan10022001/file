import React from "react";
import './AnimatedList.css';
import { motion } from '../../../Framer-Motion/motion-main/packages/framer-motion/src/render/dom/motion';
//import  uniqueNamesGenerator  from '../../../unique-names-generator-main/src/unique-names-generator.constructor';
class AnimatedList extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            items: [],
            index: 0,
            status: '',
        };
    }

    //======================================

    componentDidMount() {
        var initItems = [];
        var listElements = this.props.data;
        for (var i = 0; i < this.props.size; i++) {
            initItems.push(listElements[i]);
        }
        this.setState({
            items: initItems,
            index: this.props.size + 1,
            className: 'element',
        })
    }

    //======================================

    handleAdd() {
        var initItems = [];
        initItems.push(this.props.data[this.state.index - 1]);
        for (var i = 0; i < this.state.index - 1; i++) {
            initItems.push(this.state.items[i])
        }
        this.setState({
            items: initItems,
            index: this.state.index + 1,
        })
    }

    //======================================

    handleDelete() {
        var initItems = this.state.items;
        var temp = [];
        for(var i =1; i< this.state.items.length; i++)
        {
            temp.push(this.state.items[i]);
        }
      
        var list = document.getElementById('list');
        var size = temp.length;
        this.setState({
            items: temp,
            index: size,
        });
    

    }

    //======================================

    handleReset() {
        this.componentDidMount();
    }

    //======================================

    handleSort() {
        var initItems = this.state.items;
        initItems.sort();

        this.setState({
            items: initItems,
        })
        
    }

    //======================================

    render() {


        return (
            <div style={{ padding: '20px' }}>
                <div className="buttons">
                    <button onClick={this.handleAdd.bind(this)}>Add</button>
                    <button onClick={this.handleDelete.bind(this)}>Remove</button>
                    <button onClick={this.handleSort.bind(this)}>Sort</button>
                    <button onClick={this.handleReset.bind(this)}>Reset</button>
                </div>
                <ul id="a-list" className="list-elements" style={{ "list-style": "none" }}>
                    {this.state.items.map((row, key) => {
                        return <li className={key === 0 ? 'element show' : 'element'} key={key}>{row}</li>
                    })}
                </ul>
            </div>
        )
    }
}

export default AnimatedList;
