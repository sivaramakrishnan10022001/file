
//{<PdfViewer className='sample' pdfUrl='https://www.pdfpdf.com/samples/Sample5.PDF' pagesToShow={10} showArrows={true} showPagination={true} />} 
import React from 'react';
import { ReactComponent as Previous } from '../../../assets/icons/leftarrow.svg';
import { ReactComponent as Next } from '../../../assets/icons/rightarrow.svg';
import Document  from './msfpdflibrary/Document';
import Page from './msfpdflibrary/Page';
import { pdfjs } from './msfpdflibrary/entry';
import './pdfviewer.css';
class PdfViewer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            numPages: [],
            pageNumber: 1,
            pages: [],
            pagesToShow: 0,
            currentPage: 1,
        };
        pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
        this.onDocumentLoadSuccess = this.onDocumentLoadSuccess.bind(this);
    }
    onDocumentLoadSuccess = ({ numPages }) => {
        var temp = [];
        for (var i = 1; i <= numPages; i++) {
            temp.push(i);
        }
        this.setState({
            numPages: temp,
        })
        this.getPager(this.state.currentPage, temp.length, this.props.pagesToShow)
        console.log('new numpages = ', temp)
    };
    componentDidMount() {
        this.setState({
            currentPage: 1,
            pagesToShow: this.props.pagesToShow,
            pdfUrl: this.props.pdfUrl,
        })
        console.log('did mount', this.props)
    }
    componentWillMount() {
        this.getPager(this.state.currentPage, this.state.numPages.length, this.props.pagesToShow)
    }
    getPager(currentPage, totalPages, pageSize) {
        var pages = [];
        console.log('values passed', currentPage, totalPages, pageSize);
        if (currentPage <= parseInt(pageSize / 2)) {
            for (var i = currentPage - parseInt(pageSize / 2); i < currentPage + parseInt(pageSize / 2) + (parseInt(pageSize / 2) - currentPage + 1); i++) {
                if (i > 0 && i <= totalPages) {
                    pages.push(i);
                }
            }
        } else if (currentPage >= parseInt(pageSize/2)) {
            if (totalPages - currentPage <= parseInt(pageSize / 2)) {
                console.log('condition true')
                for (var i = totalPages - parseInt(pageSize) + 1; i < (totalPages - parseInt(pageSize) + 1) + parseInt(pageSize); i++) {
                    if (i > 0 && i <= totalPages) {
                        pages.push(i);
                    }
                }
            }
            else {
                for (var i = currentPage - parseInt(pageSize / 2); i <= currentPage + parseInt(pageSize / 2); i++) {
                    if (i > 0 && i <= totalPages) {
                        pages.push(i);
                    }
                }
            }
        }
        else if (currentPage >= parseInt(pageSize / 2)) {
            for (var i = currentPage - parseInt(pageSize / 2); i <= currentPage + parseInt(pageSize / 2) + 1; i++) {
                if (i > 0 && i <= totalPages) {
                    pages.push(i);
                }
            }
        }
        if(pages.length != pageSize)
        {
            console.log('diff length', pages.length , pageSize)
            if (pages.length > pageSize) {
                pages.pop();
            }
            else if(pages.length < pageSize){
                var dummy= pages.length;
                console.log('entering less', dummy, pageSize);
                while(pages.length != pageSize)
                {
                    pages.push(dummy+1);
                }
                console.log('updated pages',pages)
            }
        }
        console.log("totalpages and cp", pages, currentPage);
        this.setState({
            pages: pages,
            currentPage: currentPage,
            pageNumber: currentPage,
        })
        return {
            currentPage: currentPage,
            totalPages: totalPages,
            pageNumber: currentPage,
        };
    }
    render() {
        return (
            <div className={'pdf-viewer '+ this.props.className} >
                <div className='pdf-box'>
                    {this.props.showArrows ? <div className='icon' >
                        {this.state.pageNumber == 1 ? <Previous color='grey' /> : <Previous color='black' onClick={() => this.getPager(this.state.currentPage - 1, this.state.numPages.length, this.state.pagesToShow)} />}
                    </div>
                        : ""
                    }
                    <div className='pdf-page'>
                        <Document
                            file={this.state.pdfUrl}
                            onLoadSuccess={this.onDocumentLoadSuccess}>
                            <Page pageNumber={this.state.pageNumber} />
                        </Document></div>
                    {this.props.showArrows ? <div className='icon' >
                        {this.state.pageNumber == this.state.numPages.length ? <Next color='grey' /> : <Next color='black' onClick={() => this.getPager(this.state.currentPage + 1, this.state.numPages.length, this.state.pagesToShow)} />}
                    </div> : ""
                    }
                </div>
                {console.log('numpages before passing to comp', this.state.numPages)}
                {this.props.showPagination ? <div className='pdf-pagination'>
                    { this.state.currentPage == 1 ? "" : <span className='prev' onClick={() => this.getPager(this.state.currentPage - 1, this.state.numPages.length, this.state.pagesToShow)}>
                        Prev
                    </span>}
                    <span className='pageno-holder'>
                        {this.state.pages.map((row, key) => {
                            console.log("inside pageholder ", typeof (this.state.currentPage), typeof (row));
                            return <span key={key}
                            className={this.state.currentPage === row ? 'pageno active' : 'pageno'}
                                onClick={() => {
                                    console.log(this.state.currentPage === row, row, this.state.currentPage, this.state.numPages.length, this.state.pagesToShow)
                                    this.getPager(row, this.state.numPages.length, this.state.pagesToShow)}}>{row}</span>
                            })}
                    </span>
                    { this.state.currentPage == this.state.numPages.length  ? "" : <span className='next' onClick={() => this.getPager(this.state.currentPage + 1, this.state.numPages.length, this.state.pagesToShow)}>
                      Next
                    </span>}
                    </div> : ""}
            </div>
        );
    }
}
export default PdfViewer;