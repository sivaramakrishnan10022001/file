export class PDFSinglePageViewer extends BaseViewer {
    #private;
}
export class PDFViewer extends BaseViewer {
    #private;
}
import { BaseViewer } from "./base_viewer.js";
