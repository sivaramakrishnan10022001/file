import React from 'react';
// import { ReactComponent as Hamburger } from '../../../assets/icons/hamburgericon.svg';
// import { ReactComponent as Download } from '../../../assets/icons/downloadicon.svg';
// import Document from '../pdfviewer/msfpdflibrary/Document';
// import Page from '../pdfviewer/msfpdflibrary/Page';
// import { pdfjs } from '../pdfviewer/msfpdflibrary/entry';

import { ReactComponent as Hamburger } from '../../../../assets/icons/hamburgericon.svg';
import { ReactComponent as Download } from '../../../../assets/icons/downloadicon.svg';
import Document from '../msfpdflibrary/Document';
import Page from '../msfpdflibrary/Page';
import { pdfjs } from '../msfpdflibrary/entry';


import './pdfslide.css';
class PdfSlide extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            numPages: [],
            pages: [],
            pagesToShow: 0,
            currentPage: 1,
            isClicked: false,
        };
        this.sidebarTab = this.sidebarTab.bind(this);
        this.handlePageno = this.handlePageno.bind(this);
        this.getPager = this.getPager.bind(this);
        this.myRef = React.createRef();
        pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
        this.onDocumentLoadSuccess = this.onDocumentLoadSuccess.bind(this);
        window.addEventListener('scroll', this.getPager);
    }
    sidebarTab() {
        this.setState({
            isClicked: !this.state.isClicked,
        }, () => { console.log('sidebar clicked', this.state.isClicked);
        if(this.state.isClicked)
        {
            document.getElementById('page').style.marginLeft="300px"
        }
        else
        {
            document.getElementById('page').style.marginLeft="170px"
        }
       })
        
    }
    onDocumentLoadSuccess = ({ numPages }) => {
        var temp = [];
        for (var i = 1; i <= numPages; i++) {
            temp.push(i);
        }
        this.setState({
            numPages: temp,
        })
    };
    componentDidMount() {
        this.setState({
            currentPage: 1,
            pagesToShow: this.props.pagesToShow,
            pdfUrl: this.props.pdfUrl,
        });
        document.getElementById('page').style.marginLeft="170px";
    }
    componentWillMount() {
        this.handlePageno = this.handlePageno.bind(this);
    }
    getPager() {
        var list = document.getElementsByClassName('pdf-page');
        console.log('scroll listening');
        for (var i = 0; i < list.length; i++) {
            var someDiv = document.getElementById(i);
            var distanceToTop = someDiv.getBoundingClientRect().top;
            if (distanceToTop >= 0 && distanceToTop <= 500) {
                this.setState({
                    currentPage: someDiv.getAttribute('data-pagenumber'),
                })
                document.getElementById('input-box').value = this.state.currentPage;
            }
        }
    }
    handlePageno = (value) => {
        this.setState({
            currentPage: value,
        }, () => {
            if (value != "" && value != 0 && value <= this.state.numPages.length && value > 0) {
                this.myRef.scrollIntoView();
            }
        })
    }
    render() {
        return (
            <div className={'pdfSlide '+this.props.className}>
                <div className='toolbar'>
                    <div className='side-elements'>
                        <div className='side-icon' onClick={this.sidebarTab}>< Hamburger /></div>
                        <div className='side-tag'>Powerpoint Presentation</div>
                    </div>
                    <div className='page-elements'>
                        <input type="number" id='input-box' name='page_no' value={this.state.currentPage} onChange={e => this.handlePageno(e.target.value)}></input><h6> / {this.state.numPages.length}</h6>
                    </div>
                    <div className='corner-elements'>
                        <div className='download' >
                            <a href={this.state.pdfUrl} download > <Download /></a>
                        </div>
                    </div>
                </div>
                <div className='pdf-content'>
                    <Document
                        file={this.state.pdfUrl}
                        onLoadSuccess={this.onDocumentLoadSuccess}>
                    </Document>
                    <div className={this.state.isClicked ? "pdf-sidebar active" : "pdf-sidebar"}>
                        <div className='sidebar-pageholder'>
                            {this.state.numPages.map((row, key) => {
                                return this.state.currentPage == row ? (
                                    <div key={key} className='pdf-sidepage active'  >
                                        <div className='side-pager'>
                                            <Document
                                                file={this.state.pdfUrl}
                                                onLoadSuccess={this.onDocumentLoadSuccess}>
                                                <Page pageNumber={row} /><br />
                                            </Document>
                                        </div>
                                        <div className='page-num'>{row}</div><br />
                                    </div>)
                                    :
                                    (
                                        <div key={key} className='pdf-sidepage' onClick={() => this.handlePageno(row)}>
                                            <div className='side-pager'>
                                                <Document
                                                    file={this.state.pdfUrl}
                                                    onLoadSuccess={this.onDocumentLoadSuccess}>
                                                    <Page pageNumber={row} /><br />
                                                </Document>
                                            </div>
                                            <div className='page-num'>{row}</div><br />
                                        </div>
                                    )
                            })}</div>
                    </div>
                    <div className='page-holder' id='page'>
                    
                        {this.state.numPages.map((row, key) => {
                            return this.state.currentPage == row ? (
                                <div key={key} className='pdf-page active' ref={ref => this.myRef = ref} id={key} data-pagenumber={key + 1}>
                                    <Document
                                        file={this.state.pdfUrl}
                                        onLoadSuccess={this.onDocumentLoadSuccess}>
                                        <Page pageNumber={row} /><br />
                                    </Document></div>)
                                :
                                (
                                    <div key={key} className='pdf-page' id={key} data-pagenumber={key + 1}>
                                        <Document
                                            file={this.state.pdfUrl}
                                            onLoadSuccess={this.onDocumentLoadSuccess}>
                                            <Page pageNumber={row} /><br />
                                        </Document></div>
                                )
                        })}
                   </div>
                </div>
            </div>

        );
    }
}
export default PdfSlide;